#include<stdio.h>
int fact(int a)
{	
	if (a==0 || a==1)
	{ 
		return 1;
	}
	else
	{
		return a*fact(a-1);
	}
}
int main()
{	int a, f;
	printf("Enter number whose factorial is to be calculated:  ");
	scanf("%d",&a);
	
	f= fact(a);
	printf("factorial is : %d",f);
	return 0;
	}
