#include<stdio.h>
int sum(int a, int b)
{
	return a+b;
}

int main()
{
	int a,b,s;
	printf("Enter 1st integer:  ");
	scanf("%d",&a);
	printf("Enter 2nd integer:  ");
	scanf("%d",&b);
	s=sum(a,b);
	printf("Sum is %d\n",s);
	scanf("%d",&a);
	return 0;
	}
	
	
