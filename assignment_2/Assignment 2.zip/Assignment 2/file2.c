#include<stdio.h>
int func()
{
	char array1[10];
	char array2[5];
	return 0;
}
	
int main()
{	int a=1;
	int b=5;
	int c=6;
	func();
	return 0;
	}
	
